<?php
class Config
{
    
    const ENV = 'dev';

    const SITE_TITLE = 'Nirmaan Learning';
    const SITE_SUB_TITLE = 'Nirmaan Learning Portal';
    const SITE_ADMIN = 'Pavan Chowdary';
    const SERVER_MAIL = 'info@nirmaan.org';

    const BASE_URL = 'http://localhost/learning-portal/learning-portal-admin-panel/api/';
    const CORS_DOMAINS = array('localhost:3000');

    const DB_NAME = "global_internship";
    const DB_PASS = "";
    const DB_HOST = "localhost";
    const DB_USER = "root";

    const SMTP_MAIL = "no-reply@learn.nirmaan.org";
    const SMTP_HOST = "learn.nirmaan.org";
    const SMTP_USERNAME = "no-reply@learn.nirmaan.org";
    const SMTP_PASSWORD = "zxcvbnmLP.";
    const SMTP_PORT = "465";


    // const ENV = 'prod';

    // const SITE_TITLE = 'Nirmaan';
    // const SITE_SUB_TITLE = 'Nirmaan Skills Ready';
    // const SITE_ADMIN = 'pavan chowdary';
    // const SERVER_MAIL = 'info@nirmaanskills.org';

    // const BASE_URL = 'https://nirmaanskills.org/';
    // const CORS_DOMAINS = array('nirmaanskills.org');

    // const DB_NAME = "ams_staging";
    // const DB_PASS = "zxcvbnmAMS.";
    // const DB_HOST = "localhost";
    // const DB_USER = "ams_staging";
    
    // const SMTP_MAIL = "info@nirmaanskills.org";
    // const SMTP_HOST = "nirmaanskills.org";
    // const SMTP_USERNAME = "info@nirmaanskills.org";
    // const SMTP_PASSWORD = "";
    // const SMTP_PORT = "465";

    // const ENV = 'prod';

    // const SITE_TITLE = 'Nirmaan';
    // const SITE_SUB_TITLE = 'Nirmaan Skills Ready';
    // const SITE_ADMIN = 'pavan chowdary';
    // const SERVER_MAIL = 'info@nirmaanskills.org';

    // const BASE_URL = 'https://nirmaanskills.org/';
    // const CORS_DOMAINS = array('nirmaanskills.org');

    // const DB_NAME = "ams";
    // const DB_PASS = "zxcvbnmAMS.";
    // const DB_HOST = "localhost";
    // const DB_USER = "ams";
    
    // const SMTP_MAIL = "info@nirmaanskills.org";
    // const SMTP_HOST = "nirmaanskills.org";
    // const SMTP_USERNAME = "info@nirmaanskills.org";
    // const SMTP_PASSWORD = "";
    // const SMTP_PORT = "465";

}
